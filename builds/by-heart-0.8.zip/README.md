by heart
========

A simple bookmarks extension for google chrome.

Made in my spare time.

It will get better.

Learning to use github:windows
